#ifndef RANDOM_H
#define RANDOM_H

void srandom (unsigned int x);
long int random () ;

#endif
